console.log("page loaded...");

function playvideo(vid) {
    vid.play();
}

function playvideo(vid) {
    vid.pause();
    vid.currentTime = 0;
}